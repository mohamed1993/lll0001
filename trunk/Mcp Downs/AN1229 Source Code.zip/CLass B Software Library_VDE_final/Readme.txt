1. For 24f/24H devices do the following.
----------------------------------------

	 a> Set the "dsPIC30F_33F_FLAG" flag to '1'for testing 30F/33F devices in "SSL_CpuTest.inc" file.
         b> Set the "dsPIC30F_33F_FLAG" flag to '0 'for testing 24F/24H devices in "SSL_CpuTest.inc" file.

2. FOR RAM tests do the following.
----------------------------------
	a>  To invoke the "SSL_16bitsFamily_RAMtest_MarchC" function include the file "SSL_MarchCRamTest.c" file and 	                  comment the "SSL_16bitsFamily_RAM_STACKtest_MarchC" function and remove the "SSL_MarchCRamAndStackTest.c"
            from the workspace.
        b>  To invoke the "SSL_16bitsFamily_RAM_STACKtest_MarchC" function include the file "SSL_MarchCRamAndStackTest.c"                 file and comment the "SSL_16bitsFamily_RAMtest_MarchC" function and remove the "SSL_MarchCRamTest.c"
            from the workspace.
