/**********************************************************************
* � 2008 Microchip Technology Inc.
*
* FileName:        SSL_ClockTest_LineFreq.h
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC30Fxxxx/dsPIC33Fxxxx/PIC24H/PIC24F
* Compiler:        MPLAB� C30 v3.00 or higher
* Version :        1.7
* Date :           03/08/08   (mm/dd/yy)
* Author:          Veena Kudva
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip's
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP'S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.*/
/**************************************************************************************/

#ifndef __SSL_CLOCK_TEST_LINE_FREQ_H__
#define __SSL_CLOCK_TEST_LINE_FREQ_H__

#ifdef __dsPIC33F__
#include <p33Fxxxx.h>
#endif

#ifdef __dsPIC30F__
#include <p30Fxxxx.h>
#endif

#ifdef __PIC24F__
#include <p24Fxxxx.h>
#endif

#ifdef __PIC24H__
#include <p24Hxxxx.h>
#endif


#define TIMER_PRESCALAR_TCKPS  0X1           // 1:8 Prescalar for timer 2

#define TIMER_PRESCALAR  8                   // 1:8 Prescalar  

#define EVENT_ON_RISING_EDGE  0X3            // Generate capture event on every Rising edge

#define INTERRUPT_SECOND_CAPTURE_EVENT 0X1   // Interrupt on every second capture event

#define TIMER2_TIMEBASE    0X1               // Select Timer2 as the IC1 Time base

#define DISABLE_IC1  0X0                     // Disable Input Capture 1 module

#define CLOCK_ERROR 0

#define CLOCK_NO_ERROR 1

#define TIMER2_PERIOD_LINE_FREQ 65535

//Enable the respective macro for 50/60hz
#define LINE_FREQ_50HZ 1

#define LINE_FREQ_60HZ 0

// Values for 50Hz line frequency.
#if LINE_FREQ_50HZ

#ifdef __dsPIC33F__
// 4% tolerence for 14.7Mhz on dsPIC DEM board
//#define CLK_MIN_TIME_50HZ 282240 
//#define CLK_MAX_TIME_50HZ 305760
//
// 4% tolerence for 16Mhz on Explorer 16 board
#define CLK_MIN_TIME_50HZ 307200 
#define CLK_MAX_TIME_50HZ 332800

#endif

#ifdef __dsPIC30F__
// 4% tolerence for 14.7Mhz on dsPIC DEM board
//#define CLK_MIN_TIME_50HZ 282240
//#define CLK_MAX_TIME_50HZ 305760

// 4% tolerence for 16Mhz on Explorer 16 board
#define CLK_MIN_TIME_50HZ 307200 
#define CLK_MAX_TIME_50HZ 332800

#endif
#ifdef __PIC24H__
//4% tolerence for 16Mhz on Explorer 16 board
#define CLK_MIN_TIME_50HZ 307200 
#define CLK_MAX_TIME_50HZ 332800
#endif

#ifdef __PIC24F__
//4% tolerence for 15.51Mhz on Explorer 16 board
#define CLK_MIN_TIME_50HZ 297792 
#define CLK_MAX_TIME_50HZ 322608
#endif

#endif

//Values for 60Hz Line Frequency.

#if LINE_FREQ_60HZ 

#ifdef __dsPIC33F__
// 4% tolerence for 14.7Mhz on dsPIC DEM board
//#define CLK_MIN_TIME_60HZ 235200
//#define CLK_MAX_TIME_60HZ 254800

// 4% tolerence for 16Mhz on Explorer 16 board
#define CLK_MIN_TIME_60HZ 256000 
#define CLK_MAX_TIME_60HZ 277332
#endif

#ifdef __dsPIC30F__
// 4% tolerence for 14.7Mhz on dsPIC DEM board
//#define CLK_MIN_TIME_60HZ 235200
//#define CLK_MAX_TIME_60HZ 254800

// 4% tolerence for 16Mhz on Explorer 16 board
#define CLK_MIN_TIME_60HZ 256000 
#define CLK_MAX_TIME_60HZ 277332
#endif

#ifdef __PIC24H__
//4% tolerence for 16Mhz on Explorer 16 board 
#define CLK_MIN_TIME_60HZ 256000
#define CLK_MAX_TIME_60HZ 277332
#endif

#ifdef __PIC24F__
//4% tolerence for 15.51Mhz on Explorer 16 board
#define CLK_MIN_TIME_60HZ 248160 
#define CLK_MAX_TIME_60HZ 268840
#endif

#endif
void Timer2Start_LineFreq(void);
void Timer2Init_LineFreq(void);
int SSL_16bitsFamily_CLOCKtest_LineFreq(void);


#endif
