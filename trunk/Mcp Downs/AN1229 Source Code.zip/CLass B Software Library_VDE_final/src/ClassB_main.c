#include "..\h\SSL_CBram.h"
#include "..\h\SSL_MarchcRamAndStackTest.h"
#include "..\h\SSL_MarchC.h"
#include "..\h\SSL_MarchC_Minus.h"
#include "..\h\SSL_MarchB.h"
#include "..\h\SSL_Flash_CRC.h"
#include "..\h\SSL_EEPROM_CRC.h"
#include "..\h\SSL_PcTest.h"
#include "..\h\SSL_ClockTest.h"
#include "..\h\SSL_ClockSwitch.h"
#include "..\h\SSL_ClockTest_LineFreq.h"


/* Macros for Configuration Fuse Registers (copied from device header file): */

#ifdef __dsPIC30F__
_FOSC(CSW_FSCM_OFF & XT_PLL8);         /*Set up for crystal multiplied by 8x PLL */                                      /*Ensure Clock Switching is ON */
_FWDT(WDT_OFF);                         /*Turn off the Watch-Dog Timer. */
_FBORPOR(MCLR_EN & PWRT_OFF);           /*Enable MCLR reset pin and turn off the power-up timers. */
_FGS(CODE_PROT_OFF);                    /*Disable Code Protection */
#endif

#ifdef __dsPIC33F__

_FOSCSEL(FNOSC_PRI);			// Primary (XT, HS, EC) Oscillator 
_FOSC(FCKSM_CSECMD & OSCIOFNC_OFF  & POSCMD_XT);  
								// Clock Switching is enabled and Fail Safe Clock Monitor is disabled
								// OSC2 Pin Function: OSC2 is Clock Output
								// Primary Oscillator Mode: XT Crystal

_FWDT(FWDTEN_OFF);              // Watchdog Timer Enabled/disabled by user software

#endif

#ifdef __PIC24H__
_FOSCSEL(FNOSC_PRI);			// Primary (XT, HS, EC) Oscillator 
_FOSC(FCKSM_CSECMD & OSCIOFNC_OFF  & POSCMD_XT);  
								// Clock Switching is enabled and Fail Safe Clock Monitor is disabled
								// OSC2 Pin Function: OSC2 is Clock Output
								// Primary Oscillator Mode: XT Crystal

_FWDT(FWDTEN_OFF);              // Watchdog Timer Enabled/disabled by user software

#endif

#ifdef __PIC24F__
_CONFIG1(JTAGEN_OFF & GCP_OFF & GWRP_OFF & COE_OFF & FWDTEN_OFF & ICS_PGx2) 
_CONFIG2(FCKSM_CSECMD & OSCIOFNC_ON & POSCMOD_XT & FNOSC_FRC)
#endif

unsigned int testResult=0;

int SSL_16bitsFamily_CPU_RegisterTest();

struct  ClassB_Test_Flags {

unsigned int  cpuRegister_TestResult : 1;
unsigned int  programCounter_TestResult:1;
unsigned int  checkerboardRam_TestResult:1;
unsigned int  marchCRam_TestResult:1;
unsigned int  marchBRam_TestResult:1;
unsigned int  flash_TestResult:1;
unsigned int  eeprom_TestResult:1;
unsigned int  interrupt_TestResult:1;
unsigned int  clock_TestResult:1;

} testFlag;



int main(void){

#ifdef __dsPIC33F__

	// Configure Oscillator to operate the device at  
	// Fosc= Fin*M/(N1*N2), Fcy=Fosc/2
	// Fosc= 7.3M*16/(2*2)=29.4Mhz for 7.3M input clock
	PLLFBD=14;					// M=16
	CLKDIVbits.PLLPOST=0;		// N1=2
	CLKDIVbits.PLLPRE=0;		// N2=2
	OSCTUN=0;					// Tune FRC oscillator, if FRC is used

	// Disable Watch Dog Timer
	RCONbits.SWDTEN=0;

	// Clock switch to incorporate PLL
	__builtin_write_OSCCONH(0x03);		// Initiate Clock Switch to Primary
										// Oscillator with PLL (NOSC=0b011)
	__builtin_write_OSCCONL(0x01);		// Start clock switching
	while (OSCCONbits.COSC != 0b011);	// Wait for Clock switch to occur

	// Wait for PLL to lock
	while(OSCCONbits.LOCK!=1) {};	

#endif

#ifdef __PIC24H__

	// Configure Oscillator to operate the device at 14.72Mhz
	// Fosc= Fin*M/(N1*N2), Fcy=Fosc/2
	// Fosc= 7.3M*16/(2*2)=29.4Mhz for 7.3M input clock
	PLLFBD=14;					// M=16
	CLKDIVbits.PLLPOST=0;		// N1=2
	CLKDIVbits.PLLPRE=0;		// N2=2
	OSCTUN=0;					// Tune FRC oscillator, if FRC is used

	// Disable Watch Dog Timer
	RCONbits.SWDTEN=0;

	// Clock switch to incorporate PLL
	__builtin_write_OSCCONH(0x03);		// Initiate Clock Switch to Primary
										// Oscillator with PLL (NOSC=0b011)
	__builtin_write_OSCCONL(0x01);		// Start clock switching
	while (OSCCONbits.COSC != 0b011);	// Wait for Clock switch to occur

	// Wait for PLL to lock
	while(OSCCONbits.LOCK!=1) {};	

#endif

/* Include the file "SSL_ClockSwitch.s" for 24F devices*/
#ifdef __PIC24F__
	CLKDIV = 0x0;
	clockSwitch(NOSC_FRCPLL);
#endif


    /* Variables for Flash Test*/
    uReg32 startAddress;
    uReg32 endAddress;
    unsigned int flash_crc_Result=0;
    unsigned int init_CrcValue=0;

  
    #ifdef __dsPIC30F__
    unsigned int  eeprom_crc_Result;
    #endif

    /*Variables for RAM Test */
    int * ramStartAddress;
    int ramSize;

// Note:a> Set the "dsPIC30F_33F_FLAG" flag to '1'for testing 30F/33F devices in "SSL_CpuTest.inc" file.
//      b> Set the "dsPIC30F_33F_FLAG" flag to '0 'for testing 30F/33F devices in "SSL_CpuTest.inc" file.
/**********************************************************************************/
/*                                  CPU REGISTER TEST                             */                              
/**********************************************************************************/
          
    if (SSL_16bitsFamily_CPU_RegisterTest()) 
         testFlag.cpuRegister_TestResult = 1;
    else 
         testFlag.cpuRegister_TestResult = 0;

/**********************************************************************************/
/*                                  PROGRAM COUNTER TEST                          */                              
/**********************************************************************************/

    if (SSL_16bitsFamily_PCtest()) 
         testFlag.programCounter_TestResult = 1;
    else 
         testFlag.programCounter_TestResult = 0; 

/**********************************************************************************/
/*                                  RAM TEST                                      */                              
/**********************************************************************************/
   
   /*************************/
   /* Checker Board RAM test*/
   /*************************/
    ramStartAddress = ( int *) CB_RAMSTARTADDRESS ;

    ramSize = CB_RAM_SIZE;

    if (SSL_16bitsFamily_RAMtest_CheckerBoard(ramStartAddress,ramSize)) 
        testFlag.checkerboardRam_TestResult = 1;
    else
        testFlag.checkerboardRam_TestResult = 0;

// To invoke the "SSL_16bitsFamily_RAMtest_MarchC" function include the file "SSL_MarchCRamTest.c" file and comment 
// the "SSL_16bitsFamily_RAM_STACKtest_MarchC" function and remove the "SSL_MarchCRamAndStackTest.c"
// from the workspace.

/* Include either MarchC RAM test function (or) MarchC RAM and Stack Test Function*/

   /*************************/
   /*    MarchC RAM test    */
   /*************************/
  
//     ramStartAddress = ( int *) MARCHC_RAM_START_ADDRESS ;
//     
//     ramSize = MARCHC_RAM_SIZE;
//  
//     if (SSL_16bitsFamily_RAMtest_MarchC(ramStartAddress,ramSize )) 
//        testFlag.marchCRam_TestResult = 1;
//     else
//        testFlag.marchCRam_TestResult = 0;
//
   /**************************/
   /* MarchC Minus RAM test  */
   /**************************/

     ramStartAddress = ( int *) MARCHC_MINUS_RAM_START_ADDRESS ;
     
     ramSize = MARCHC_MINUS_RAM_SIZE;
  
     if (SSL_16bitsFamily_RAMtest_MarchC_Minus(ramStartAddress,ramSize )) 
        testFlag.marchCRam_TestResult = 1;
     else
        testFlag.marchCRam_TestResult = 0;  

// To invoke the "SSL_16bitsFamily_RAM_STACKtest_MarchC" function include the file "SSL_MarchCRamAndStackTest.c" file 
// and comment the "SSL_16bitsFamily_RAMtest_MarchC" function and remove the "SSL_MarchCRamTest.c"
// from the workspace.

 /****************************/
  /* MarchC RAM and Stack Test*/
  /****************************/
//    ramStartAddress = ( int *) MARCHC_RAMTEST_START_ADDRESS ;
//
//    ramSize = MARCHC_RAMTEST_SIZE;
//
//    if (SSL_16bitsFamily_RAM_STACKtest_MarchC(ramStartAddress,ramSize )) 
//        testFlag.marchCRam_TestResult = 1;
//    else
//        testFlag.marchCRam_TestResult = 0;

  /****************************/
  /*    March B Ram Test      */
  /****************************/

      ramStartAddress = (int *) MARCHB_RAM_START_ADDRESS ;

      ramSize = MARCHB_RAM_SIZE;

      if (SSL_16bitsFamily_RAMtest_MarchB(ramStartAddress,ramSize )) 
        testFlag.marchBRam_TestResult = 1;
      else
         testFlag.marchBRam_TestResult = 0;

  
/**********************************************************************************/
/*                                  FLASH TEST                                    */                              
/**********************************************************************************/
 // This function can be called at startup to generate the Reference checksum.The 
 // same function can be called periodically and the generated checksum can be 
 // compared with the reference checksum. If both are the same the "flash_TestResult"
 // status bit can be set. 
    startAddress.Val32= FLASH_STARTADDRESS;

    endAddress.Val32 =  FLASH_ENDADDRESS;

    flash_crc_Result = SSL_16bitsFamily_Flashtest_CRC16(startAddress,endAddress,init_CrcValue);
     
/**********************************************************************************/
/*                                  EEPROM TEST                                   */                              
/**********************************************************************************/
 // This function can be called at startup to generate the Reference checksum.The 
 // same function can be called periodically and the generated checksum can be 
 // compared with the reference checksum. If both are the same the "eeprom_TestResult"
 // status bit can be set
#ifdef __dsPIC30F__
    startAddress.Val32= EEPROM_STARTADDRESS;

    endAddress.Val32 =  EEPROM_ENDADDRESS;

    eeprom_crc_Result = SSL_16bitsFamily_EEPROMtest_CRC16(startAddress,endAddress,init_CrcValue);
#endif
     
// Comment the "SSL_16bitsFamily_CLOCKtest()" function while performing the clock test 
// with line frequency as refernce clock beacuse the Timer2 module is also used by the 
// "SSL_16bitsFamily_CLOCKtest()" function.
/**********************************************************************************/
/*        CLOCK  TEST WITH SECONDARY OSCILLATOR AS REFERENCE CLOCK                */                             
/**********************************************************************************/

       if (SSL_16bitsFamily_CLOCKtest()) 
          testFlag.clock_TestResult=1;
       else 
          testFlag.clock_TestResult=0;
/**********************************************************************************/
/*      CLOCK  TEST WITH 50HZ/60Hz LINE FREQUENCY AS REFERENCE CLOCK              */                             
/**********************************************************************************/

        if (SSL_16bitsFamily_CLOCKtest_LineFreq()) 
          testFlag.clock_TestResult=1;
        else 
          testFlag.clock_TestResult=0; 
            
      while(1);
      return 0;


}
 


