/**********************************************************************
* � 2008 Microchip Technology Inc.
*
* FileName:        SSL_ClockTest.c
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC30Fxxxx/dsPIC33Fxxxx/PIC24H/PIC24F
* Compiler:        MPLAB� C30 v2.01.00 or higher
* Version :        1.7
* Date :           03/03/08   (mm/dd/yy)
* Author:          Veena Kudva
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* KVK                        First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/
#include "..\h\SSL_ClockTest.h"
#include "..\h\SSL_ClockSwitch.h"


volatile unsigned int clockTestFlag;

unsigned int timer2Count;


  /************************************************************************************************
  * Description:
  *     The SSL_16bitsFamily_CLOCKtest function is used to verify proper operation of the CPU clock when
  *      the secondary oscillator is used as the reference clock.
  *       The test performs the following major tasks:
  *			1. The LP secondary oscillator is used as the independent clock source or the reference clock
  *            source. The secondary oscillator, which is designed with 32 kHz crystal, is used as a clock
  *            source to the Timer1.
  *         2. The Primary oscillator with PLL is the clock source to the CPU. The Timer2 runs at the CPU
  *            clock frequency.
  *         3. The Timer1 is configured to generate an interrupt at specified intervals of time (e.g., 1 ms).
  *         4. The PR2 register in the Timer2 module holds the time period value. It must be initialized to a value
  *            greater than 1 ms so that the TIMER2 does not time out before the occurrence of a Timer1 interrupt.
  *         5. The contents of TMR2 register in Timer2 module are saved in the Timer1 interrupt handler. This
  *             value represents the number of CPU Clock cycles of the secondary clock in 1ms. If the number
  *             of clock cycles crosses the defined boundary limits, the function sets an error flag.
  *             For example, the following parameters are used to calculate CLK_MIN_TIME and CLK_MAX_TIME for a
  *             dsPIC30F device:
  *				Primary Oscillator: XT_PLL8
  *				FOSC: 7.37 Mhz * 8
  *				FCY: FOSC/4: (7.37 * 10^6 * 8) / 4
  *				FCY: 14740000
  *				Secondary oscillator: 32KHz
  *			    Timer1 period register (PR1): 31
  *             Therefore, with 4% tolerance, the number of CPU clock cycles in 1ms (14740 cycles) are:
  *					� CLK_MIN_TIME: 14150
  *					� CLK_MAX_TIME: 15330
  *  Input: None 
  *        
  * Return Values:
  *   	CLOCK_NO_ERROR : CPU clock is operating within its limits.
  *     CLOCK_ERROR    : CPU clock is not operating within limits                           
  ****************************************************************************************************/



unsigned int SSL_16bitsFamily_CLOCKtest(void ){

 int clockTest=0;

  Timer2Init();  					// Initialize Timer 2

  Timer2Start();				    // Enable Timer 2

  LP_enable();                      // Enable LP Secondary oscillator

  Timer1Init();                     // Initialze Timer 1

  Timer1Start();                    // Enable Timer 2

   while ( clockTestFlag !=TIMER2_PERIOD_CHECK);     // Wait till clockTestFlag=10 and
                                                     // read timer2count value
   clockTestFlag=0;

    if (timer2Count > CLK_MAX_TIME || timer2Count < CLK_MIN_TIME )
  {
      clockTest =1;
  }

        if( clockTest==1)
		return CLOCK_ERROR;
        else
        return CLOCK_NO_ERROR;
}



void Timer1Init(void ){

    T1CON = 0x0002;            //Stop the Timer1, set ext clk TCS=1  
	TMR1 = 0x0000;             //Clear contents of the timer_1 register
	PR1 = TIMER1_PERIOD;       //Init period reg for 1ms
}

void Timer1Start(void)
{
	
	IFS0bits.T1IF=0;           //Clear the Timer1 interrupt status flag
	IEC0bits.T1IE = 1;         //Enable Timer1 interrupts
	T1CONbits.TON=1;           // Enable Timer 
}



void Timer2Init(void){

	TMR2 = 0x0000;            //Clear contents of the Timer 1 register

	PR2   = TIMER2_PERIOD;    // Load the period register with the value 0xFFFF.

}

void Timer2Start(void){

	T2CONbits.TON=1;  

}


void LP_enable(void)
{
 __builtin_write_OSCCONL(0x0002);
}


void __attribute__((__interrupt__,no_auto_psv)) _T1Interrupt(void)

{
 
 clockTestFlag++;            //Set flag

 IFS0bits.T1IF=0;            //Clr Timer1 interrupt flag

 timer2Count = TMR2;

 TMR2=0;

}

