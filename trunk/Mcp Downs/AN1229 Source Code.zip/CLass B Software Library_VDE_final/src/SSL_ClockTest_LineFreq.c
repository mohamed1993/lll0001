/**********************************************************************
* � 2008 Microchip Technology Inc.
*
* FileName:        SSL_ClockTest_LineFreq.c
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC30Fxxxx/dsPIC33Fxxxx/PIC24H/PIC24F
* Compiler:        MPLAB� C30 v2.01.00 or higher
* Version :        1.7
* Date :           03/08/08   (mm/dd/yy)
* Author:          Veena Kudva
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* KVK                        First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/
#include "..\h\SSL_ClockTest_LineFreq.h"
#include "..\h\SSL_ClockSwitch.h"

// Capture Interrupt Service Routine

volatile long timer2count = 0;

volatile int clockStatusFlag=0;

  /************************************************************************************************
  * Description:
  *  The SSL_16bitsFamily_CLOCKtest_LineFreq function is used to verify the proper operation of the
  * CPU clock. The 50 Hz/60 Hz line frequency is used as the independent clock source or the reference 
  * clock source. The Input capture module is used for Periodmeasurement. The 50 Hz/60 Hz line frequency 
  * is fed to the Input capture pin (IC1) of the respective device.
  *		The test performs the following major tasks:
  *         1. The IC1CON register is configured as follows:
  *				� Timer2 is selected as IC1 time base
  *				� Interrupt is generated on every second capture event.
  *				� Capture event is generated on every rising edge
  *         2. IC1 generates an interrupt after every 20 ms if line frequency is 50 Hz and after every 16.66ms
  *             if the line frequency is 60 Hz.The Timer2 pre-scalar is configured to operate in 1:8 mode 
  *             so that the timer count does not time out within 20 ms/16.66 ms.
  *        3. The capture event is generated on every rising edge of Line frequency. For period
  *           measurement, the capture interrupt is generated after taking two time stamps.
  *      FCY= 14.7Mhz
  *      PR2 =65535
  *      TIMER_PRESCALAR = 1:8 
  *      With this configuration the timer can count upto   65535 * 8 = 524280 /FCY = 35ms
  *      The number of counts that will be counted in the 20ms is  = 0.02 * 14700000 = 294000.
  *      With tolerance of 4%
  *	 	 #define CLK_MIN_TIME 282240 
  *      #define CLK_MAX_TIME 305760
  *   
  *
  * Input: None 
  *        
  * Return Values:
  *   	CLOCK_NO_ERROR : CPU clock is operating within its limits.
  *     CLOCK_ERROR    : CPU clock is not operating within limits     
  *  Note : set LINE_FREQ_50HZ to 1 for 50Hz line frequency in SSL_ClockTest_LineFreq.h file
  *         set LINE_FREQ_60HZ to 1 for 60Hz line frequency in SSL_ClockTest_LineFreq.h file
  *                    
  ****************************************************************************************************/
int  SSL_16bitsFamily_CLOCKtest_LineFreq(){


  Timer2Init_LineFreq();

  // Initialize Capture Module
  IC1CONbits.ICM= DISABLE_IC1; 			                    // Disable Input Capture 1 module
  IC1CONbits.ICTMR= TIMER2_TIMEBASE; 			            // Select Timer2 as the IC1 Time base
  IC1CONbits.ICI= INTERRUPT_SECOND_CAPTURE_EVENT; 			// Interrupt on every second capture event
  IC1CONbits.ICM= EVENT_ON_RISING_EDGE;		                // Generate capture event on every Rising edge

// Enable Capture Interrupt And Timer2
  IPC0bits.IC1IP = 1; 										// Setup IC1 interrupt priority level
  IFS0bits.IC1IF = 0; 										// Clear IC1 Interrupt Status Flag
  Timer2Start_LineFreq();
  IEC0bits.IC1IE = 1; 										// Enable IC1 interrupt

   while( clockStatusFlag ==0);

   clockStatusFlag=0;
  
    #if LINE_FREQ_50HZ

   if ( timer2count < CLK_MIN_TIME_50HZ || timer2count > CLK_MAX_TIME_50HZ)
        return CLOCK_ERROR;
   else
        return CLOCK_NO_ERROR;
   #endif


   #if LINE_FREQ_60HZ
   if ( timer2count < CLK_MIN_TIME_60HZ || timer2count > CLK_MAX_TIME_60HZ)
        return CLOCK_ERROR;
   else
        return CLOCK_NO_ERROR;
   #endif


}

void Timer2Init_LineFreq(void){

	TMR2 = 0x0000;                        //Clear contents of the Timer 1 register
 
    T2CONbits.TCKPS= TIMER_PRESCALAR_TCKPS;     // 1:8 Timer prescalar is used

	PR2   = TIMER2_PERIOD_LINE_FREQ;      // Load the period register with the Max value 0xFFFF.

}

void Timer2Start_LineFreq(void){

	T2CONbits.TON=1;  

}

void __attribute__((__interrupt__,no_auto_psv)) _IC1Interrupt(void)
{
unsigned int t1,t2;
unsigned int timePeriod;
t1=IC1BUF;
t2=IC1BUF;
IFS0bits.IC1IF=0;
if(t2>t1)
timePeriod = t2-t1;
else
timePeriod = (PR2 - t1) + t2;

timer2count = (long) timePeriod * TIMER_PRESCALAR;   // CPU cycles = timer period * 8
                                                     // This is because of 1:8 Timer prescalar
clockStatusFlag=1;

}


