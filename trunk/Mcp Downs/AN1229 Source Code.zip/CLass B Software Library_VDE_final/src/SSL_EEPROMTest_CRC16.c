/**********************************************************************
* � 2008 Microchip Technology Inc.
*
* FileName:        SSL_EEPROMTest_CRC16.c
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC30Fxxxx
* Compiler:        MPLAB� C30 v2.01.00 or higher
* Version :        1.7
* Date :           02/14/08   (mm/dd/yy)
* Author:          Veena Kudva
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* KVK                        First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/

#include "..\h\SSL_EEPROM_CRC.h"
#include "..\h\Typedef.h"

  /********************************************************************
  * Description:
  *     The " SSL_16bitsFamily_EEPROMtest_CRC16 " function Calculates the CRC of the data starting 
  *     fromAddress "EEPROM_STARTADDRESS" to "EEPROM_ENDADDRESS". This function returns the final CRC Value.
  *     The data EEPROM is mapped into the program memory space.The EEPROM is organized as 16-bit
  *     wide memory. The amount of EEPROM is device dependent.  
  *     CRC-16 is used as a divisor.
  *     CRC-16 = 1 1000 0000 0000 0101= 8005(hex)
  *     The CRC Result genearated by the "SSL_16bitsFamily_EEPROMtest_CRC16" function can be used to do the following:
  *     1. With CRC_Flag = 0x00, the CRC checksum is computed to generate the new Reference checksum.
  *     2. This Reference Checksum is stored in the FLASH or EEPROM memory 
  *     3. To Verify the checksum, the CRC flag is set to 0xFF and the CRC checksum routine is invoked again.    
  *     4. This calculated Check sum is compared with the Reference checksum.
  *     5. If the calculated and reference checksum are the same a status bit can be set in the code.
  * Input:
  *     startAddress :  start Address from which the CRC needs to be
  *                     calculated
  *     endAddress :    This address indicates the Final address upto
  *                     which the CRC is calculated
  * Return Values:
  *     crc_Result :  \Returns the final CRC result.
  *                                                                  
  ********************************************************************/

unsigned int SSL_16bitsFamily_EEPROMtest_CRC16(uReg32 startAddress,uReg32 endAddress,unsigned int crc_Result)
{
  int i;
  uReg32 temp;
 // unsigned int crc_Result=0;
  unsigned int partialCRC_Result=0;
 
  char Buffer[EEDATA_BYTES];
	
  for( i=0; endAddress.Val32 >= startAddress.Val32;i++)
  	{
        partialCRC_Result=0;

  	   TBLPAG = startAddress.Word.HW;
       temp.Word.LW = __builtin_tblrdl(startAddress.Word.LW);
       temp.Word.HW = __builtin_tblrdh(startAddress.Word.LW);


		Buffer[0]= temp.Val[0];
    
        Buffer[1]= temp.Val[1];
      
        EEPROM_CRC_Checksum(Buffer, &partialCRC_Result ); 

        crc_Result= crc_Result + partialCRC_Result;
        
        startAddress.Val32 = startAddress.Val32 + 2;

 	}

 return crc_Result;

}
  /********************************************************************************************
  * Description  : Calculates the Partial Checksum for EEDATA_BYTES (One EEPROM location)
  *
  * Input:
  *     ptrData :            ptr to buffer for which the partial CRC
  *                          needs to be calculated
  *     partialCRC_Result :  This pointer holds the partial CRC result
  * Return Values:
  *     None                                                          
  *********************************************************************/


void EEPROM_CRC_Checksum(char * ptrData ,unsigned int * partialCRC_Result)
{  
   int i;
   unsigned int tempCRC=0;
   * partialCRC_Result=0;
   
   for (i=0;i<EEDATA_BYTES ;i++)
   {
   		EEPROM_CRC16(ptrData[i],&tempCRC);
   		*partialCRC_Result= *partialCRC_Result+tempCRC;
   }


}


  /********************************************************************************************
  * Function Name: EEPROM_CRC16     
  * 
  * Description  : Calculates the  CRC checkksum for a byte of data. 
  * Input:
  *     Data :     Data for which the CRC needs to be calculated
  *     tempCRC :  This pointer holds the CRC result for the Data that
  *                is passed.
  * Return Values:
  *     : None                                                          
  *********************************************************************/
void EEPROM_CRC16(char Data,  unsigned int *tempCRC) 
{
    int i ;

    *tempCRC=0;

    for ( i = 8 ; i > 0 ; i-- )  {
        if ( (Data ^ (*tempCRC)) & 0x8000 ) {
           (*tempCRC) = ((*tempCRC)<< 1) ^ EEPROM_GEN_POLY ;
        }
        else {
            (*tempCRC) <<= 1 ;
        }
        Data <<= 1 ;
    }

}

