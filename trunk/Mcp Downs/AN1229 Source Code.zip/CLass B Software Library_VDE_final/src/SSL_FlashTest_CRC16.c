/**********************************************************************
* � 2008 Microchip Technology Inc.
*
* FileName:        SSL_FlashTest_CRC16.c
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC30Fxxxx/dsPIC33Fxxxx/PIC24H/PIC24F
* Compiler:        MPLAB� C30 v2.01.00 or higher
* Version :        1.7
* Date :           02/11/08   (mm/dd/yy)
* Author:          Veena Kudva
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* KVK                        First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/
#include "..\h\SSL_Flash_CRC.h"
#include "..\h\Typedef.h"

  /********************************************************************
  * Description:
  *     The "SSL_16bitsFamily_Flashtest_CRC16" function Calculates the CRC of the
  *     data starting from address "FLASH_STARTADDRESS" to
  *     "FLASH_ENDADDRESS".This function returns the final CRC Value.
  *     
  *     CRC-16 is used as a divisor.
  *     
  *     CRC-16 = 1 1000 0000 0000 0101= 8005(hex).
  *
  *     The CRC Result genearated by the "SSL_16bitsFamily_Flashtest_CRC16" function can be used to do the following:
  *     1. At startup the CRC_Flag = 0x00 and the CRC checksum computed is the Reference checksum.
  *     2. This Reference Checksum is stored in the FLASH or EEPROM memory and the CRC flag is set to 0xFF. 
  *     3. The SSL_16bitsFamily_Flashtest_CRC16 can be called periodically if the CRC flag is set to 0xFF.    
  *     4. This calculated Check sum is compared with the Reference checksum.
  *     5. If the calculated and reference checksum are the same a status bit can be set in the code to indicate that
  *         the test has passed
  *           
  * Input:
  *     startAddress :  start Address from which the CRC needs to be
  *                     calculated
  *     endAddress :    This address indicates the Final address upto
  *                     which the CRC is calculated
  * Return Values:
  *  crc_Result:   Returns the final CRC result.                               
  ********************************************************************/

unsigned int SSL_16bitsFamily_Flashtest_CRC16(uReg32 startAddress,uReg32 endAddress,unsigned int crc_Result)
{

  int i;
  uReg32 temp;
 // unsigned int crc_Result=0;
  unsigned int partialCRC_Result=0;
 
  char Buffer[PM_NUM_BYTES];
	
  for( i=0; endAddress.Val32 >= startAddress.Val32;i++)
  	{
        partialCRC_Result=0;
  
       TBLPAG = startAddress.Word.HW;
       temp.Word.LW = __builtin_tblrdl(startAddress.Word.LW);
       temp.Word.HW = __builtin_tblrdh(startAddress.Word.LW);


		Buffer[0]= temp.Val[0];
    
        Buffer[1]= temp.Val[1];

        Buffer[2]= temp.Val[2];

        Flash_CRC_Checksum(Buffer, &partialCRC_Result ); 

      
        crc_Result= crc_Result + partialCRC_Result;
        
        startAddress.Val32 = startAddress.Val32 + 2;

 	}

 return crc_Result;

}

  /*********************************************************************
  * Description:
  *     Calculates the Partial Checksum for PM_NUM_BYTES(One program
  *     memory location)
  * Input:
  *     ptrData :            ptr to buffer for which the partial CRC
  *                          needs to be calculated
  *     partialCRC_Result :  This pointer holds the partial CRC result
  * Return Values:
  *     None                                                          
  *********************************************************************/

void Flash_CRC_Checksum(char * ptrData ,unsigned int * partialCRC_Result)
{  
   int i;
   unsigned int tempCRC=0;
   * partialCRC_Result=0;
   
   for (i=0;i<PM_NUM_BYTES ;i++)
   {
   		Flash_CRC16(ptrData[i],&tempCRC);
   		*partialCRC_Result= *partialCRC_Result+tempCRC;
   }


}
  /*********************************************************************
  * Description:
  *     Calculates the CRC checkksum for a byte of data.
  * Input:
  *     Data :     Data for which the CRC needs to be calculated
  *     tempCRC :  This pointer holds the CRC result for the Data that
  *                is passed.
  * Return Values:
  *     : None                                                          
  *********************************************************************/

void Flash_CRC16(char Data,  unsigned int *tempCRC) 
{
    int i ;

    *tempCRC=0;

    for ( i = 8 ; i > 0 ; i-- )  {
        if ( (Data ^ (*tempCRC)) & 0x8000 ) {
           (*tempCRC) = ((*tempCRC)<< 1) ^ FLASH_GEN_POLY ;
        }
        else {
            (*tempCRC) <<= 1 ;
        }
        Data <<= 1 ;
    }

}

