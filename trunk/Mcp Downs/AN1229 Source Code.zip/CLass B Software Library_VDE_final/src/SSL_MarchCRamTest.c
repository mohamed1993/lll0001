/**********************************************************************
* � 2008 Microchip Technology Inc.
*
* FileName:        SSL_MarchCRamTest.c
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC30Fxxxx/dsPIC33Fxxxx/PIC24H/PIC24F
* Compiler:        MPLAB� C30 v2.01.00 or higher
* Version :        1.7
* Date :           02/14/08   (mm/dd/yy)
* Author:          Veena Kudva
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* KVK                        First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/
#include "..\h\SSL_MarchC.h"

static int ReadZeroWriteOne(volatile int *);
static int ReadOneWriteZero(volatile int *);
static int ReadZero(volatile int *);

  /**********************************************************************
  * Description:
  *     This function implements the March C test .The test is suited
  *     to find all stuck-at faults ,transition faults and coupling
  *     faults.The complexity of this test is 11n ( n is the number
  *     of bits). This test uses Word( 16-bit) accesses. The address
  *     must be properly aligned to the data type and the length must
  *     be an integral multiple of the data width.This is a destructive
  *     test i.e, the memory contents is not preserved.Hence this
  *     test is meant to be run at system startup, before the memory
  *     and the run time library is initialized. The memory will be
  *     cleared (=0) when "SSL_16bitsFamily_RAMtest_MarchC" test
  *     \returns.
  *     
  *     
  * Input:
  *     ramStartAddress :  Address were March C algorithm starts.<p />
  *     ramSize :          Number of bytes for which the test is to be
  *                        performed. The size must be a even number.
  * Return Values:
  *     MARCHC_RAM_TEST_FAIL : return value = 0
  *     MARCHC_RAM_TEST_PASS : return value = 1
  *                                                    
  **********************************************************************/

int  SSL_16bitsFamily_RAMtest_MarchC(int * ramStartAddress,int ramSize)
	{
    int testResult; 
 	int  * ptr;   	
  
	// erase all sram
   	    for(ptr=ramStartAddress ; ptr< ramStartAddress + (ramSize/2) ; ptr++)
           *ptr=0x0000;                                         //write 0
        
    
   //Test Bitwise if 0 and replace it with 1 starting from lower Addresses
   	    for(ptr=ramStartAddress; ptr<ramStartAddress + (ramSize/2); ptr++)
         {

          testResult =  ReadZeroWriteOne(ptr);

           if ( !testResult)
             return MARCHC_RAM_TEST_FAIL;
        
       	 } 

  //Test Bitwise if 1 and replace it with 0 starting from lower Addresses
        for(ptr=ramStartAddress; ptr<ramStartAddress + (ramSize/2); ptr++)
         {
            
           testResult =  ReadOneWriteZero(ptr);

           if ( !testResult)
             return MARCHC_RAM_TEST_FAIL;
      
         }                  

 //Test if all bits are zeros starting from lower Addresses
        for(ptr=ramStartAddress; ptr<ramStartAddress + (ramSize/2); ptr++)
         {
            
            testResult =  ReadZero(ptr);

          if ( !testResult)
             return MARCHC_RAM_TEST_FAIL;
         }

//Test Bitwise if 0 and replace it with 1 starting from higher Addresses
        for (ptr=ramStartAddress + (ramSize/2-1);ptr>=(ramStartAddress);ptr--) 
         {  

        	  testResult =  ReadZeroWriteOne(ptr);

         	 if ( !testResult)
             return MARCHC_RAM_TEST_FAIL;

         }
//Test Bitwise if 1 and replace it with 0 starting from higher Addresses
        for (ptr=(ramStartAddress + (ramSize/2-1));ptr>=(ramStartAddress);ptr--) 
         {  
            testResult =  ReadOneWriteZero(ptr);

			 if ( !testResult)
             return MARCHC_RAM_TEST_FAIL;
         }

//Test if all bits are zeros starting from higher Addresses
        for (ptr=(ramStartAddress + (ramSize/2-1));ptr>=(ramStartAddress);ptr--) 
         {  
            testResult =  ReadZero(ptr);

			 if ( !testResult)
             return MARCHC_RAM_TEST_FAIL;
         }

    return testResult;

   } // End of function



  /*******************************************************************
  * Description:
  *     This function tests bitwise if a bit is zero and replaces it
  *     with one.
  * Input:
  *     ptr :  Address location of the the bits to be tested
  * Return Values:
  *     MARCHC_RAM_TEST_FAIL :  return value = 0
  *     MARCHC_RAM_TEST_PASS :  return value = 1
  *                                                                 
  *******************************************************************/


static int ReadZeroWriteOne(volatile int * ptr)
    {
	int  tempValue;  
    int loopCounter;

            for (loopCounter=MARCHC_BIT_WIDTH-1;loopCounter>=0;loopCounter--)
              {
                     
				  tempValue =(((*ptr)>>loopCounter) & 0x01);  // read 0 
                  if (tempValue!= 0x00) 
                     {
                         return MARCHC_RAM_TEST_FAIL;
                     } 
                  
                  *ptr=(*ptr | (1<<loopCounter));             // write 1
          
              }

    return MARCHC_RAM_TEST_PASS;  
  
	}

  /******************************************************************
  * Description:
  *     This function tests bitwise if a bit is one and replaces it
  *     with zero.
  * Input:
  *     ptr :  Address location of the the bits to be tested
  * Return Values:
  *     MARCHC_RAM_TEST_FAIL :  return value = 0
  *     MARCHC_RAM_TEST_PASS :  return value = 1
  *                                                                
  ******************************************************************/


static int ReadOneWriteZero(volatile int * ptr ) 

    {

	int  tempValue;  
    int loopCounter;


          for (loopCounter=0;loopCounter<MARCHC_BIT_WIDTH ;loopCounter++)
              {

                  tempValue =(((*ptr)>>loopCounter) & 0x01);     // read 1 

		          if (tempValue!= 0x01) 
     			   {
            			return MARCHC_RAM_TEST_FAIL;
     			   }


 		 	      tempValue =  *ptr  & ~(1<<loopCounter);       // write 0
                  *ptr= tempValue;     

                }
     return MARCHC_RAM_TEST_PASS; 
    }

  /***********************************************************
  * Description:
  *     This function tests bitwise if all bits are zeros .
  * Input:
  *     ptr :  Address location of the the bits to be tested
  * Return Values:
  *     MARCHC_RAM_TEST_FAIL :  \return value = 0<p />
  *     MARCHC_RAM_TEST_PASS :  \return value = 1
  *                                                         
  ***********************************************************/
static int ReadZero(volatile int * ptr ) 
     {

	int  tempValue;  
    int loopCounter;

            for (loopCounter=0;loopCounter<MARCHC_BIT_WIDTH ;loopCounter++)
              {

                 tempValue =(((*ptr)>>loopCounter) & 0x01);    // read 0 

        		 if (tempValue!= 0x00) 
        		   {
                        return MARCHC_RAM_TEST_FAIL;
                   }

               }
    return MARCHC_RAM_TEST_PASS; 
     }

