/**********************************************************************
* � 2008 Microchip Technology Inc.
*
* FileName:        SSL_MarchC_MinusRamTest.c
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC30Fxxxx/dsPIC33Fxxxx/PIC24H/PIC24F
* Compiler:        MPLAB� C30 v2.01.00 or higher
* Version :        1.7
* Date :           02/05/08   (mm/dd/yy)
* Author:          Veena Kudva
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* KVK                        First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/

  /**********************************************************************
  * Description:   
  * Input:
  *     ramStartAddress :  Address were March C algorithm starts.
  *     ramSize :          Number of bytes for which the test is to be
  *                        performed. The size must be a even number.
  * Return Values:
  *     MARCHC_RAM_TEST_FAIL : return value = 0
  *     MARCHC_RAM_TEST_PASS : return value = 1
  *                                                    
  **********************************************************************/
#include "..\h\SSL_MarchC_Minus.h"

int  SSL_16bitsFamily_RAMtest_MarchC_Minus(int * ramStartAddress,int ramSize)
	{

     int  * ptr;
     int tempData;
		
	 for(ptr=ramStartAddress ; ptr< ramStartAddress + (ramSize/2) ; ptr++)
      *ptr=0xAAAA;         				   //write 0XAAAA
		
	 for(ptr=ramStartAddress; ptr<ramStartAddress + (ramSize/2); ptr++)
        {	
	  	
        tempData = *ptr ;                  //read 0xAAAA
        if ( tempData != 0xAAAA)           //Check if 0xAAAA
         	 return MARCHC_RAM_TEST_FAIL;
        else 
             *ptr= 0x5555;                 //write 0X5555
		}

	 for(ptr=ramStartAddress; ptr<ramStartAddress + (ramSize/2); ptr++)
        {	
				
        tempData = *ptr ; 				  //read 0x5555
        if ( tempData != 0x5555)          //Check if 0x5555
         	 return MARCHC_RAM_TEST_FAIL;
        else 
             *ptr= 0xAAAA; 				 //write 0AAAA
		}

    for (ptr=(ramStartAddress + (ramSize/2-1));ptr>=(ramStartAddress);ptr--) 
        { 
		tempData = *ptr ; 				//read 0xAAAA
        if ( tempData != 0xAAAA)        //Check if 0xAAAA
         	 return MARCHC_RAM_TEST_FAIL;
        else 
             *ptr= 0x5555; 				 //write 0x5555
        }

    for (ptr=(ramStartAddress + (ramSize/2-1));ptr>=(ramStartAddress);ptr--) 
        { 
		tempData = *ptr ; 				//read 0x5555
        if ( tempData != 0x5555)        //Check if 0x5555
         	 return MARCHC_RAM_TEST_FAIL;
        else 
             *ptr= 0xAAAA; 				 //write 0xAAAA
        }

        return MARCHC_RAM_TEST_PASS;
  
	}
