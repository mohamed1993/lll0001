
/**********************************************************************
* � 2008 Microchip Technology Inc.
*
* FileName:        SSL_MarchCRamAndStackTest.c
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC30Fxxxx/dsPIC33Fxxxx/PIC24H/PIC24F
* Compiler:        MPLAB� C30 v2.01.00 or higher
* Version :        1.7
* Date :           02/07/08   (mm/dd/yy)
* Author:          Veena Kudva
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* KVK                        First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/
#include "..\h\SSL_MarchcRamAndStackTest.h"

int ssl_RamTestResult;
static int ReadZeroWriteOne(volatile int *);
static int ReadOneWriteZero(volatile int *);
static int MarchCStackTest(void);  
static int ReadZero(volatile int *);

  /*************************************************************************
  * Description:
  *     Function Name: SSL_16bitsFamily_RAM_STACKtest_MarchC
  *     
  *     This function implements the March C test on Ram and Stack.This test is suited to
  *     find all stuck-at faults ,transition faults and coupling faults The complexity of 
  *     this test is 11n( n is the number of bits). This test uses Word( 16-bit)accesses. 
  *     The address must be properly aligned to the data type and the length must be an 
  *     integral multiple of the data width.This function also tests the stack area by 
  *     copying the stack contents into an already tested Ram area. It then performs March C
  *     test on the stack area. After the stack is tested it restores the contents of the stack.
  *     This is a destructive test i.e, the memory contents is not preserved.Hence this test is
  *     meant to be run at system startup, before the memory and the run time library is 
  *     initialized. The memory will be cleared (=0) when "SSL_16bitsFamily_RAM_STACKtest_MarchC"
  *     test returns
  *      NOTE:
  *      1: The user application should allocate 0x50 bytes for stack before executing the
  *         March C or March B test. The stack must be allocated at a appropriate address
  *         such that it is not over written during the RAM test.
  *      2: It is recommended that the stack should be placed at the beginning or at the end
  *         of the data memory. The user application should specify an ram test start address 
  *        such that it does not overlap with other statically allocated resources, such as
  *          the MPLAB ICD and RAM buffer at 0x800.
  *       3: The following example shows the changes are made in the ".gld" file before 
  *          executing March B or March C test.  
  *           .stack 0x850:       //stack start address
  *      		{
  *				__SP_init = .;
  *				. += 0x50;        //stack length
  *				__SPLIM_init = .;  
  *				. += 8;
  * 			} >data
  * Input:
  *     ramStartAddress :  Address were March C algorithm starts.
  *     ramSize :          Number of bytes for which the test is to be
  *                        performed. The size must be a even number.
  * Return Values:
  *     MARCHC_RAM_STACK_TEST_FAIL :  return value = 0
  *     MARCHC_RAM_STACK_TEST_PASS :  return value = 1                      
  *************************************************************************/

int   SSL_16bitsFamily_RAM_STACKtest_MarchC(int * ramStartAddress,int ramSize)
	{
    register int in1   asm("w15");
    int  * S_ptr;
 	int  * ptr;   	
  
	// erase all sram
   	    for(ptr=ramStartAddress ; ptr< ramStartAddress + (ramSize/2) ; ptr++)
           *ptr=0x0000;                                         //write 0
        
    
   //Test Bitwise if 0 and replace it with 1 starting from lower Addresses
   	    for(ptr=ramStartAddress; ptr<ramStartAddress + (ramSize/2); ptr++)
         {

          ssl_RamTestResult =  ReadZeroWriteOne(ptr);

           if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
        
       	 } 

  //Test Bitwise if 1 and replace it with 0 starting from lower Addresses
        for(ptr=ramStartAddress; ptr<ramStartAddress + (ramSize/2); ptr++)
         {
            
           ssl_RamTestResult =  ReadOneWriteZero(ptr);

           if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
      
         }                  

 //Test if all bits are zeros starting from lower Addresses
        for(ptr=ramStartAddress; ptr<ramStartAddress + (ramSize/2); ptr++)
         {
            
            ssl_RamTestResult =  ReadZero(ptr);

          if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
         }

//Test Bitwise if 0 and replace it with 1 starting from higher Addresses
        for (ptr=ramStartAddress + (ramSize/2-1);ptr>=(ramStartAddress);ptr--) 
         {  

        	  ssl_RamTestResult =  ReadZeroWriteOne(ptr);

         	 if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;

         }
//Test Bitwise if 1 and replace it with 0 starting from higher Addresses
        for (ptr=(ramStartAddress + (ramSize/2-1));ptr>=(ramStartAddress);ptr--) 
         {  
            ssl_RamTestResult =  ReadOneWriteZero(ptr);

			 if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
         }

//Test if all bits are zeros starting from higher Addresses
        for (ptr=(ramStartAddress + (ramSize/2-1));ptr>=(ramStartAddress);ptr--) 
         {  
            ssl_RamTestResult =  ReadZero(ptr);

			 if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
         }


/* Initialize a pointer pointing to already tested RAM address where the stack needs to be saved before testing*/
      	S_ptr = (int *)MARCHC_RAMTEST_START_ADDRESS;

/*Save the stack region in Tested RAM region*/

      	for (ptr = (int*)(MARCHC_STACK_START_ADDRESS); ptr <= (int*)(MARCHC_STACK_START_ADDRESS+MARCHC_STACK_LENGTH) ; ptr++)
      	  { 
       		 *( S_ptr++) = *(ptr) ;
      	  }

      /* save the stack pointer */
      	*(S_ptr++)=in1;
      	*(S_ptr++)=SPLIM;

      /*reinitialize the stack pointer and SPLIM register*/
   
        in1=(int )S_ptr;
        S_ptr=S_ptr+MARCHC_STACK_LENGTH;
        SPLIM= (int)S_ptr;

      /*Test the stack region*/
      ssl_RamTestResult= MarchCStackTest();        

      /* restore the stack region*/
        S_ptr = (int *)MARCHC_RAMTEST_START_ADDRESS;
         for (ptr =(int *)(MARCHC_STACK_START_ADDRESS); ptr <= (int *)(MARCHC_STACK_START_ADDRESS+MARCHC_STACK_LENGTH); ptr++)
          { 
              *(ptr) = *( S_ptr++) ;
          }

   
    /* restore stack pointer */
         in1 =   *( S_ptr++);
         SPLIM  =   *( S_ptr++);

      for(ptr=ramStartAddress; ptr<ramStartAddress + MARCHC_STACK_LENGTH; ptr++)
    *ptr=0;

 
        if (  ssl_RamTestResult)
     	    return MARCHC_RAM_STACK_TEST_PASS;
        else 
        	 return MARCHC_RAM_STACK_TEST_FAIL; 


  

   } // End of function



 /********************************************************************************************
  * Function Name: ReadZeroWriteOne      
  * 
  * Description  : This function tests bitwise if a bit is zero and replace it with one.
  * 
  *
  * Input:
  *      ptr: Address location of the the bits to be tested 
  *						
  * Return Values:
  *     TEST_FAIL: return value = 0
  *     
  *     TEST_PASS: return value = 1 
*********************************************************************************************/


static int ReadZeroWriteOne(volatile int * ptr)
    {
	int  TempValue;  
    int LoopCounter;

            for (LoopCounter=MARCHC_RAM_BIT_WIDTH-1;LoopCounter>=0;LoopCounter--)
              {
                     
				  TempValue =(((*ptr)>>LoopCounter) & 0x01);  // read 0 
                  if (TempValue!= 0x00) 
                     {
                         return MARCHC_RAM_STACK_TEST_FAIL;
                     } 
                  
                  *ptr=(*ptr | (1<<LoopCounter));             // write 1
          
              }

    return MARCHC_RAM_STACK_TEST_PASS;  
  
	}

 /*********************************************************************************************
 * Function Name:ReadOneWriteZero      
  * 
  * Description  :  This function tests bitwise if a bit is one and replace it with zero.
  *
  * Input:
  *      ptr: Address location of the the bits to be tested 
  *						
  * Return Values:
  *     TEST_FAIL: return value = 0
  *     
  *     TEST_PASS: return value = 1 

**********************************************************************************************/


static int ReadOneWriteZero(volatile int * ptr ) 

    {

	int  TempValue;  
    int LoopCounter;


          for (LoopCounter=0;LoopCounter<MARCHC_RAM_BIT_WIDTH ;LoopCounter++)
              {

                  TempValue =(((*ptr)>>LoopCounter) & 0x01);     // read 1 

		          if (TempValue!= 0x01) 
     			   {
            			return MARCHC_RAM_STACK_TEST_FAIL;
     			   }


 		 	      TempValue =  *ptr  & ~(1<<LoopCounter);       // write 0
                  *ptr= TempValue;     

                }
     return MARCHC_RAM_STACK_TEST_PASS; 
    }

/*********************************************************************************************
* Function Name:ReadZero      
  * 
  * Description  :  This function tests bitwise if all bits are zeros 

  * Input:
  *      ptr: Address location of the the bits to be tested 
  *						
  * Return Values:
  *     TEST_FAIL: return value = 0
  *     
  *     TEST_PASS: return value = 1
**********************************************************************************************/
static int ReadZero(volatile int * ptr ) 
     {

	int  TempValue;  
    int LoopCounter;

            for (LoopCounter=0;LoopCounter<MARCHC_RAM_BIT_WIDTH ;LoopCounter++)
              {

                 TempValue =(((*ptr)>>LoopCounter) & 0x01);    // read 0 

        		 if (TempValue!= 0x00) 
        		   {
                        return MARCHC_RAM_STACK_TEST_FAIL;
                   }

               }
    return MARCHC_RAM_STACK_TEST_PASS; 
     }






 /******************************************************************
  * Description:
  *     Function Name: MarchCStackTest
  *     
  *     This function performs the stack test starting from address
  *     "MARCHC_STACK_START_ADDRESS" and length
  *     "MARCHC_STACK_LENGTH".
  * Return Values:
  *     MARCHC_RAM_STACK_TEST_FAIL :  \return value = 0<p />
  *     MARCHC_RAM_STACK_TEST_PASS :  \return value = 1
  *                                                                
  ******************************************************************/

static int MarchCStackTest(){

  	int  * ptr;   	
  
   
    int ssl_RamTestResult; 

	    for(ptr=(int*)MARCHC_STACK_START_ADDRESS; ptr<=(int*)(MARCHC_STACK_START_ADDRESS+MARCHC_STACK_LENGTH); ptr++)
         {  
             *ptr=0; 
         }


 //Test Bitwise if 0 and replace it with 1 from low Address
   	    for(ptr=(int*)MARCHC_STACK_START_ADDRESS; ptr<=(int*)(MARCHC_STACK_START_ADDRESS+MARCHC_STACK_LENGTH); ptr++)
         {
             ssl_RamTestResult =  ReadZeroWriteOne(ptr);

           if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
        
             
      	 } 

 //Test Bitwise if 1 and replace it with 0 starting from lower Addresses
        for(ptr=(int*)MARCHC_STACK_START_ADDRESS; ptr<=(int*)(MARCHC_STACK_START_ADDRESS+MARCHC_STACK_LENGTH); ptr++)
         {
            
           ssl_RamTestResult =  ReadOneWriteZero(ptr);

           if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
      
         }                  

 //Test if all bits are zeros starting from lower Addresses
        for(ptr=(int*)MARCHC_STACK_START_ADDRESS; ptr<=(int*)(MARCHC_STACK_START_ADDRESS+MARCHC_STACK_LENGTH); ptr++)
         {
            
            ssl_RamTestResult =  ReadZero(ptr);

          if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
         }

//Test Bitwise if 0 and replace it with 1 starting from higher Addresses
        for (ptr=(int*)(MARCHC_STACK_START_ADDRESS+MARCHC_STACK_LENGTH);ptr>=(int*)(MARCHC_STACK_START_ADDRESS);ptr--) 
         {  

        	  ssl_RamTestResult =  ReadZeroWriteOne(ptr);

         	 if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;

         }
//Test Bitwise if 1 and replace it with 0 starting from higher Addresses
        for (ptr=(int*)(MARCHC_STACK_START_ADDRESS+MARCHC_STACK_LENGTH);ptr>=(int*)(MARCHC_STACK_START_ADDRESS);ptr--) 
         {  
            ssl_RamTestResult =  ReadOneWriteZero(ptr);

			 if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
         }

//Test if all bits are zeros starting from higher Addresses
        for (ptr=(int*)(MARCHC_STACK_START_ADDRESS+MARCHC_STACK_LENGTH);ptr>=(int*)(MARCHC_STACK_START_ADDRESS);ptr--) 
         {  
            ssl_RamTestResult =  ReadZero(ptr);

			 if ( !ssl_RamTestResult)
             return MARCHC_RAM_STACK_TEST_FAIL;
         }

   
       
   return MARCHC_RAM_STACK_TEST_PASS;
}
