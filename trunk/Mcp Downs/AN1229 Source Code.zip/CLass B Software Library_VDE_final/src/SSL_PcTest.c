/**********************************************************************
* � 2008 Microchip Technology Inc.
*
* FileName:        SSL_PcTest.c
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC30Fxxxx/dsPIC33Fxxxx/PIC24H/PIC24F
* Compiler:        MPLAB� C30 v2.01.00 or higher
* Version :        1.7
* Date :           02/20/08   (mm/dd/yy)
* Author:          Veena Kudva
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* KVK                        First release of source file
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/
#include "..\h\SSL_PcTest.h"

  /*******************************************************************
  * Description:
  * The Program Counter test is a functional test of the PC. The PC holds the address 
  * of the next instruction tO be executed.
  * The tests performs the following major tasks:
  *		1. The Program Counter test invokes functions that are located in Flash memory at different addresses.
  *		2. These functions return a unique value( address of the respective functions).
  *		3. The returned value is verified using the "SSL_16bitsFamily_PCtesT" function.
  * Return Values:
  *     PC_TEST_FAIL :  return value = 0.
  *     PC_TEST_PASS :  return value = 1.
  *                                                                    
  *******************************************************************/

int SSL_16bitsFamily_PCtest (){

	 long returnAddress,tempAddress;

    //store Address of SSL_TestFunction1
 	tempAddress= (long)&SSL_TestFunction1;

    // Branch to SSL_TestFunction1
    returnAddress=SSL_TestFunction1();

    // Test if the address of "SSL_TestFunction1" returned is the same
		if( tempAddress != returnAddress)
  		 	return PC_TEST_FAIL;

   // store Address of SSL_TestFunction2
 	tempAddress= (long )&SSL_TestFunction2;

   // Branch to SSL_TestFunction2
 	returnAddress=SSL_TestFunction2();

   // Test if the address of "SSL_TestFunction2" returned is the same
		if( tempAddress != returnAddress)
  			 return PC_TEST_FAIL;


  return PC_TEST_PASS;

}



  /********************************************************************
  * Description:
  * This function is placed in the section called "SslTestSection1".The section
  * is located in a defined address where the PC needs to jump using the custom linker script,
  * This function returns the address of the SSL_TestFunction1. 
  * In this example the function SSL_TestFunction1 is placed in a section SslTestSection1 at the 
  * address 0x900 by modifying the linker script as follows.
  *
  *  SslTestSection1 0x900 :
  *  {
  *      *(.SslTestSection1);
  *  } program 
  *
  * Return Values:     
  *      returnAddress: returns the address of SSL_TestFunction1
  *
  ********************************************************************/
long __attribute__((__section__(".SslTestSection1"))) SSL_TestFunction1() 
{

	return( (long)&SSL_TestFunction1);

}
/********************************************************************
  * Description:
  *  This function is placed in the section called "SslTestSection2".The section
  * is located in a defined address where the PC needs to jump using the custom linker script,
  * This function returns the address of the SSL_TestFunction2.
  * Return Values:     
  *      returnAddress: returns the address of SSL_TestFunction2
  *            
  ********************************************************************/

long __attribute__((__section__(".SslTestSection2"))) SSL_TestFunction2() 
{

	return( (long)&SSL_TestFunction2);

}
